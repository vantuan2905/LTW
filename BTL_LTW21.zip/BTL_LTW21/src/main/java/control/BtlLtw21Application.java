package control;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtlLtw21Application {

	public static void main(String[] args) {
		SpringApplication.run(BtlLtw21Application.class, args);
	}

}
