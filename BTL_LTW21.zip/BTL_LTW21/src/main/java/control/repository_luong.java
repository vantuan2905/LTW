package control;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface repository_luong extends JpaRepository<luong, String> {

}
