package control;

import java.sql.Date;
public class chamcongkey {
	
	private Date ngay;
	private String manv;
}
